//
//  ViewController.m
//  练习1
//
//  Created by admin on 15/12/15.
//  Copyright © 2015年 zhaoao. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface ViewController ()
{
    CAShapeLayer *arcLayer;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor=[UIColor grayColor];
    [self configUI];
}

-(void)configUI
{
    //创建path
    UIBezierPath *path=[UIBezierPath bezierPath];
    
    CGRect rect=[UIScreen mainScreen].bounds;
    //添加路径到path
    [path addArcWithCenter:CGPointMake(rect.size.width/2,rect.size.height/2-20) radius:50.0 startAngle:0 endAngle:2*M_PI clockwise:YES];
    //将path绘制出来
//    [path stroke];
    
    arcLayer=[CAShapeLayer layer];
    arcLayer.path=path.CGPath;
    arcLayer.frame=self.view.frame;
    //边框设置透明色
    arcLayer.path=path.CGPath;//46,169,230
    arcLayer.fillColor=[UIColor colorWithRed:46.0/255.0 green:169.0/255.0 blue:230.0/255.0 alpha:1].CGColor;
    arcLayer.strokeColor=[UIColor colorWithWhite:1 alpha:0.7].CGColor;
    arcLayer.lineWidth=3;
    [self.view.layer addSublayer:arcLayer];
    
//    [self drawLineAnimation:arcLayer];
    NSTimer *timer= [NSTimer scheduledTimerWithTimeInterval:1.2 target:self selector:@selector(drawLineAnimation:) userInfo:nil repeats:YES];
    [timer fire];
    
}

-(void)drawLineAnimation:(CALayer *)layer
{
    layer=arcLayer;
    CABasicAnimation *bas=[CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    bas.duration=1;
    bas.fromValue=[NSNumber numberWithInteger:0];
    bas.toValue=[NSNumber numberWithInteger:1];
    [layer addAnimation:bas forKey:@"key"];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
