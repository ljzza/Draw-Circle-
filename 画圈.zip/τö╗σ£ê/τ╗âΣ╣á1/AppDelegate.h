//
//  AppDelegate.h
//  练习1
//
//  Created by admin on 15/12/15.
//  Copyright © 2015年 zhaoao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

